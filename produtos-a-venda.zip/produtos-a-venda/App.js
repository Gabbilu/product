// import { NavigationContainer } from '@react-navigation/native';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import React from 'react';

// import Home from './src/pages/home/product/productDetails1'; // Caminho RELATIVO correto
// import Product from './src/pages/home/product/index';
// import ProductDetails1 from './src/pages/productDetails1/index';

// const Stack = createNativeStackNavigator();

// export default function App() {
//   return (
//     <NavigationContainer>
//       <Stack.Navigator initialRouteName="Home">
//         <Stack.Screen name="Home" component={Home} />
//         <Stack.Screen name="Product" component={Product} />
//         <Stack.Screen name="ProductDetails1" component={ProductDetails1} />
//       </Stack.Navigator>
//     </NavigationContainer>
//   );
// }
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';

import Home from './src/pages/home';
import Product from './src/pages/product';
import ProductDetails1 from './src/pages/productDetails1';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Product" component={Product} />
        <Stack.Screen name="ProductDetails1" component={ProductDetails1} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}