import { View, Text, Button, StyleSheet } from 'react-native';

export default function ProductDetails1({ route, navigation }) {
  const { produto } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>{produto.nome}</Text>
      <Text style={styles.desc}>{produto.descricao}</Text>
      <Text style={styles.preco}>{produto.preco}</Text>
      <Button title="Voltar" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20},
  titulo: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  desc: { fontSize: 16, marginBottom: 10 },
  preco: { fontSize: 18, color: 'green', marginBottom: 20 },
});