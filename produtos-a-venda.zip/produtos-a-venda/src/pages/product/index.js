import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

const produtos = [
  { id: '3', nome: 'Jet', preco: 'R$ 65.000', descrica6: 'Jet novo azul.' },
  { id: '2', nome: 'Lancha', preco: 'R$ 1.147.000', descricao: 'lancha.' },
  { id: '1', nome: 'Barco', preco: 'R$ 1.335.000', descricao: 'barco.' },
   { id: '4', nome: 'Devil May Cry', preco: 'R$ 200', descricao: 'jogo eletrônico' },
];

export default function Product({ navigation }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={produtos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('ProductDetails1', { produto: item })}
          >
            <Text style={styles.nome}>{item.nome}</Text>
            <Text>{item.preco}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  item: { padding: 15, backgroundColor: '#eee', marginBottom: 10, borderRadius: 10 },
  nome: { fontWeight: 'bold' },
});