// import { View, Text, Button, StyleSheet } from 'react-native';

// export default function Home({ navigation }) {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Bem-vindo, apenas vendemos carros modificados.</Text>
//       <Button title="Ver Modelos" onPress={() => <Image> navigation.navigate('Product')} />
//       <Button title="Informações" onPress={() => navigation.navigate('ProductDetails2')} />
//     />
//   );
// }

// const styles = StyleSheet.create({
//   container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
//   title: { fontSize: 20, marginBottom: 20, textAlign: 'center' },
// });

import { View, Text, Button, StyleSheet } from 'react-native';

export default function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bem-vindo, ao XLO </Text>
      <Button 
        title="Ver Modelos" 
        onPress={() => navigation.navigate('Product')} 
        color="red"
      />
      <View style={styles.spacing} />
      <Button 
        title="Informações" 
        onPress={() => navigation.navigate('ProductDetails2')} 
        color="red"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    padding: 20, 
    backgroundColor: 'black'
  },
  title: { 
    fontSize: 20, 
    marginBottom: 20, 
    textAlign: 'center', 
    color: 'white'
  },
  spacing: {
    height: 10,
  },
});